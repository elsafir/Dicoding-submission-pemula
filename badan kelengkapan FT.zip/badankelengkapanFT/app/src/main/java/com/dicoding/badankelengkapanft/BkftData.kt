package com.dicoding.badankelengkapanft

object BkftData { private val bkftNames = arrayOf("BEM",
        "DPM",
        "HIMATIF",
        "HIMASI",
        "HIMAMEKA",
        "HMM",
        "HMTI",
        "HIMATRO",
        "ITC",
        "BLUE MURDER")

    private val bkftDetails = arrayOf("merupakan bagian tertinggi dalam badan kelengkapan fakultas teknik yang menaungi aspirasi dan kegiatan teman teman fakultas teknik dan seluruh BKFT lainnya",
            "DPM atau yang biasa di kenal dengan Dewan Perwakilan Mahasiswa yang ada di setiap Fakultas Salah satunya fakultas teknik.",
            "Himatif atau himpunan mahasiswa teknik informatika merupakan organisasi mahasiswa yang di khususkan untuk mahasiswa teknik informatika yang berguna untuk menyerap aspirasi mahasiswa khususnya prodi teknik informatika.",
            "Himasi merupakan singkatan dari himpunan mahasiswa sistem informasi, yang berfungsi untuk mewadahi aspirasi mahasiswa prodi sistem informasi.",
            "Program studi D3 Mekatronika didirikan pada tahun 2010 di Universitas Trunojoyo Madura. Awal berdirinya program studi D3 Mekatronika, mahasiswa masih terbilang sedikit sehingga untuk mendirikan sebuah himpunan masih belum memenuhi syarat. Namun untuk mewadahi minat dan bakat mahasiswa Mekatronika di bidang soft skill, mahasiswa Mekatronika bergabung bersama mahasiswa Multimedia Jaringan.",
            "Diawali dengan adanya keinginan mengembangkan jurusan yang baru di buka pada tahun 2016 dan tanggung jawab sebagai angkatan pertama prodi teknik mesin universitas trunojoyo madura, angkatan pertama mahasiswa prodi teknik mesin fakultas teknik universitas trunojoyo madura sebagai perintis telah sepakat untuk membentuk suatu wadah bagi aktifitas mereka. Selanjutnya wadah itu diberi nama Himpunan Mahasiswa Mesin yang disingkat HMM, Wadah tersebut dibentuk sebagai media untuk menunjukkan kegiatan mahasiswa mesin yang terkenal aktif dan dinamis.",
            "merupakan badan kelengkapan mahasiswa fakultas teknik yang menjadi wadah aspirasi bagi mahasiswa program studi teknik informatika",
            "HIMATRO (Himpunan Mahasiswa Teknik Elektro) Merupakan badan eksekutif mahasiswa tingkat prodi yang menaungi mahasiswa teknik elektro UTM",
            "UKMFT-ITC adalah salah satu Unit Kegiatan Mahasiswa Fakultas Teknik Universitas Trunojoyo Madura. Berawal dari kelompok yang diberi nama \"Kelompok Penguna Komputer\" dan akhirnya mendeklarasikan dirinya dengan nama \"Information Technology Center\" pada tanggal 05 Oktober 2002.",
            " Blue Murder merupakan salah satu unit kegiatan mahasiswa di fakultas teknik Universitas Trunojoyo Madura yang bergerak dalam bidang seni dan musik. Arti nama dari Blue Murder sendiri ialah Blue = Biru, Murder = Pembunuh(jangan dikira pembunuh orang ya..!!), yang artinya ukm-ft blue murder merupakan wadah atau organisasi yang bertujuan untuk membunuh kejenuhan para mahasiswa di universitas Trunojoyo khususnya di fakultas teknik, soalnya kan, di teknik sudah terkenal yang namanya, pratikum, laporan, dsb.")

    private val bkftImages = intArrayOf(R.drawable.bem,
            R.drawable.dpm,
            R.drawable.logo_himatif,
            R.drawable.himasi,
            R.drawable.himameka,
            R.drawable.hmm,
            R.drawable.hmti,
            R.drawable.himatro,
            R.drawable.itc,
            R.drawable.murder)

    val listData: ArrayList<Bkft>
        get() {
            val list = arrayListOf<Bkft>()
            for (position in bkftNames.indices) {
                val bkft = Bkft()
                bkft.name = bkftNames[position]
                bkft.detail = bkftDetails[position]
                bkft.photo = bkftImages[position]
                list.add(bkft)
            }
            return list
        }
}