package com.dicoding.badankelengkapanft

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.ActionBar
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions

class detail_bkft : AppCompatActivity() {
    companion object {
        const val EXTRA_IMAGE = "extra_image"
        const val EXTRA_NAME = "extra_name"
        const val EXTRA_GENDER = "extra_gender"

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_bkft)
        supportActionBar?.title = "Halaman Detail"

        val imgLegendDetail: ImageView = findViewById(R.id.img_item_photo)
        val tvLegendNameDetail: TextView = findViewById(R.id.tv_set_name)
        val tvLegendGenderDetail: TextView = findViewById(R.id.tv_set_identity)

        val imgDetail = intent.getIntExtra(EXTRA_IMAGE, 0)
        val nameDetail = intent.getStringExtra(EXTRA_NAME)
        val genderDetail = intent.getStringExtra(EXTRA_GENDER)

        imgLegendDetail.setImageResource(imgDetail)
        tvLegendNameDetail.text = nameDetail
        tvLegendGenderDetail.text = genderDetail

    }
}