package com.dicoding.badankelengkapanft

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ListBkftAdapter (
    val legends: ArrayList<Bkft>,
    val onItemClickCallback: ListBkftAdapterInterface
) :
    RecyclerView.Adapter<ListBkftAdapter.viewHolder>() {

    class viewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvName: TextView = itemView.findViewById(R.id.tv_item_name)
        val tvdetail: TextView = itemView.findViewById(R.id.tv_item_detail)
        val imgbkft: ImageView = itemView.findViewById(R.id.img_item_photo)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): viewHolder {
        val layout: View =
            LayoutInflater.from(parent.context).inflate(R.layout.item_row_bkft, parent, false)

        return viewHolder(layout)
    }

    override fun onBindViewHolder(holder: viewHolder, position: Int) {
        val legend = legends[position]

        holder.tvName.text = legend.name
        holder.tvdetail.text = legend.detail
        holder.imgbkft.setImageResource(legend.photo)

        holder.itemView.setOnClickListener { onItemClickCallback.onItemClicked(legend) }
    }

    override fun getItemCount(): Int {
        return legends.size
    }

    interface ListBkftAdapterInterface {
        fun onItemClicked(legend: Bkft)
    }
}

