package com.dicoding.badankelengkapanft

data class Bkft(
        var name: String = "",
        var detail: String = "",
        var photo: Int = 0
)